package com.fanset.peter.nyazika.exercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PeterNyazikaExerciseApplicationTests {

	@Test
	void contextLoads() {
	}

}
